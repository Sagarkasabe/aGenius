﻿
    $(function() {
        $("#txtDate").datepicker();
      
    });
