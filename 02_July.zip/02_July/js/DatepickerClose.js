﻿$(document).mouseup(function (e) {
    $("[id*=txtdate]").Close(); 
});