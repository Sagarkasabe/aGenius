﻿
    $(function () {
        $('#error').click(function () {
            // make it not dissappear
            toastr.error("Noooo oo oo ooooo!!!", "Title", {
                "timeOut": "0",
                "extendedTImeout": "0"
            });
        });
    $('#info').click(function () {
        // title is optional
        toastr.info("Info Message", "Title");
    });
            $('#warning').click(function () {
        toastr.warning("Warning");
    });
            $('#success').click(function () {
        toastr.success("YYEESSSSSSS");
    });
});
    