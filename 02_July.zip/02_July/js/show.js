﻿debugger;
$(document).ready(function () {


    $('#GridView').click(function () {
        $('#GridView').show();
        $('#Channel').hide();
    });
});
