﻿$(function () {
    $("[id*=txtdate]").datepicker()/*.datepicker("setDate", new Date())*/;   
    format: "mm/dd/yyyy"
}).on('change', function () {
    $('.datepicker').hide();
    });


//onSelect: $(function (selectedDate) {
//    var option = this.id == "[id*=txtdate]" ? "minDate" : "maxDate", instance
//        = $(this).data("datepicker");
//    date = $.datepicker.parseDate(instance.settings.dateFormat
//        || $.datepicker._defaults.dateFormat, selectedDate, instance.settings);
//    dates.not(this).datepicker("option", option, date);
//});

