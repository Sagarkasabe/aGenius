﻿$(document).ready(function () {
    //$('#txtdate').datepicker();
    $("[id*=txtdate]").datepicker();      
    $("[id*=txtdate]").focus(function () {
        $(this).datepicker("show");
        setTimeout(function () {
            $("[id*=txtdate]").datepicker("hide");
            $("[id*=txtdate]").blur();
        }, 2000)
    })
});