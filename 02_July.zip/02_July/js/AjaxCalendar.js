﻿
$(document).ready(function () {
            $('#txtDate').datepicker({
            changeMonth: true,
            changeYear: true,


        });
    });
