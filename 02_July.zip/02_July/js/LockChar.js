﻿
function CheckNumericKeyInfo(char1, mozChar) {
    if (mozChar != null) { // Look for a Mozilla-compatible browser
        if ((mozChar >= 48 && mozChar <= 57) || char1 == 8)
            RetVal = true;
        else {
            RetVal = false;
        }
    }
    else { // Must be an IE-compatible Browser
        if ((char1 >= 48 && char1 <= 57) || char1 == 8) RetVal = true;
        else {
            RetVal = false;
        }
    }
    return RetVal;
}