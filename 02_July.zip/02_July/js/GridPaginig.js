﻿$(document).ready(function () {
    $("#GridView1").prepend($("<thead></thead>").append($(this).find("tr:first"))).DataTable();
});